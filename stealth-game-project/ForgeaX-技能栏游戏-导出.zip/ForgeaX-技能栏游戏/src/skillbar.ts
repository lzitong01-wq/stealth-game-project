import { Update, type World } from '@forgeax/engine/ecs';
import { INPUT_SNAPSHOT_RESOURCE_KEY, type InputSnapshot } from '@forgeax/engine/input';

export type ItemStatus = 'unused' | 'flying' | 'hit' | 'placed-unused' | 'placed-used' | 'used';

export interface GameItem {
  slot: number;
  keyCode: string;
  keyLabel: string;
  name: string;
  glyph: string;
  color: string;
  count: number;
  effect: string;
  /** 告示式怪谈说明，使用后揭示 */
  notice: string;
  status: ItemStatus;
  range: number;
}

const STATUS_LABEL: Record<ItemStatus, string> = {
  unused: '未使用',
  flying: '实体飞行中',
  hit: '已碰撞',
  'placed-unused': '已布置未使用',
  'placed-used': '已布置已使用',
  used: '已使用',
};

// 状态播报文案：按策划案"强光致停 / 声音吸引"的怪谈语气改写
const FLAVOR = {
  noticeTitle: '未张贴的告示',
  noticeRule: 'XX照相馆自进入起暂停营业。（或许旺铺出租？）',
  noticeHint: '告示末尾一行小字：第三件物品，不可尽信。',
  safe: '安全',
  alert: '警戒',
  fakeSafe: '注意——此处并非安全屋。',
};

export const ITEMS: GameItem[] = [
  {
    slot: 1,
    keyCode: 'Digit1',
    keyLabel: '1',
    name: '眩晕弹',
    glyph: '✦',
    color: '#e8c987', // 暖黄：安全屋灯光色
    count: 5,
    effect: '强光致停 · 2 秒',
    notice: '光会让它停下来。别盯着看太久。',
    status: 'unused',
    range: 5,
  },
  {
    slot: 2,
    keyCode: 'Digit2',
    keyLabel: '2',
    name: '麻痹陷阱',
    glyph: '◈',
    color: '#5fd4c4', // 暗青：等距桌球室冷调
    count: 3,
    effect: '麻痹 · 3 秒',
    notice: '踩上去的，就别再动了。',
    status: 'unused',
    range: 2,
  },
  {
    slot: 3,
    keyCode: 'Digit3',
    keyLabel: '3',
    name: '诱饵',
    glyph: '▲',
    color: '#e05252', // 红：警戒色
    count: 2,
    effect: '声响引诱',
    notice: '它会引开它们——有时也会引来。',
    status: 'unused',
    range: 8,
  },
];

// 等距视角配色：暗青底 + 暖黄安全屋 + 红色警戒
const css = `
.sb-hud{position:absolute;right:22px;bottom:22px;display:flex;gap:14px;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;user-select:none}
.sb-slot{position:relative;width:78px;height:78px;border-radius:12px;border:2px solid rgba(95,212,196,.32);background:linear-gradient(160deg,rgba(13,28,30,.88),rgba(8,20,22,.92));display:flex;align-items:center;justify-content:center;transition:transform .12s ease,border-color .12s ease,box-shadow .12s ease;backdrop-filter:blur(6px)}
.sb-slot .sb-key{position:absolute;top:-10px;left:-10px;width:26px;height:26px;border-radius:8px;background:rgba(8,20,22,.95);border:1px solid rgba(232,201,135,.45);color:#e8c987;font-size:14px;font-weight:600;display:flex;align-items:center;justify-content:center}
.sb-slot .sb-glyph{font-size:34px;line-height:1;text-shadow:0 0 14px currentColor}
.sb-slot .sb-count{position:absolute;right:-8px;bottom:-8px;min-width:26px;height:26px;padding:0 6px;border-radius:13px;background:#e8dcc0;color:#1a1610;font-size:14px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.4)}
.sb-slot .sb-name{position:absolute;bottom:-22px;left:50%;transform:translateX(-50%);white-space:nowrap;color:#b9d6d0;font-size:12px;letter-spacing:.5px}
.sb-slot.sb-used{transform:scale(.9);border-color:rgba(232,201,135,.9);box-shadow:0 0 26px rgba(232,201,135,.55)}
.sb-slot.sb-selected{border-color:rgba(232,201,135,.95);box-shadow:0 0 24px rgba(232,201,135,.4) inset}
.sb-slot.sb-betray{border-color:#e05252;box-shadow:0 0 30px rgba(224,82,82,.7);animation:sb-shake .35s ease}
@keyframes sb-shake{0%{transform:translateX(0)}25%{transform:translateX(-4px)}75%{transform:translateX(4px)}100%{transform:translateX(0)}}
.sb-slot.sb-empty{opacity:.35}
.sb-slot.sb-empty .sb-count{background:#7b8090;color:#1a1d24}
/* 告示面板：泛黄纸张 + 规则怪谈文案 */
.sb-log{position:absolute;left:16px;top:16px;width:290px;max-height:230px;overflow:hidden;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:12px;line-height:1.55;color:#e8dcc0;background:linear-gradient(150deg,rgba(28,34,30,.9),rgba(14,22,22,.92));border:1px solid rgba(232,201,135,.32);border-radius:6px;padding:12px 14px;backdrop-filter:blur(6px);box-shadow:0 8px 30px rgba(0,0,0,.45)}
.sb-log.sb-danger{border-color:rgba(224,82,82,.7);background:linear-gradient(150deg,rgba(42,20,20,.92),rgba(20,12,12,.95));color:#ffb3b3}
.sb-log .sb-log-title{font-size:14px;font-weight:700;color:#e8c987;margin-bottom:6px;letter-spacing:2px;border-bottom:1px dashed rgba(232,201,135,.4);padding-bottom:6px}
.sb-log.sb-danger .sb-log-title{color:#ff6b6b;border-color:rgba(224,82,82,.5)}
.sb-log .sb-rule{font-size:12px;color:#d8cba8;font-style:italic;margin:6px 0 3px}
.sb-log.sb-danger .sb-rule{color:#ff9a9a}
.sb-log .sb-lines{margin-top:6px;padding-top:6px;border-top:1px solid rgba(232,201,135,.18)}
.sb-log .sb-line{opacity:.9;margin:2px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sb-alert{float:right;font-size:11px;font-weight:700;letter-spacing:1px;padding:1px 7px;border-radius:4px;background:rgba(232,201,135,.16);color:#e8c987;border:1px solid rgba(232,201,135,.4)}
.sb-log.sb-danger .sb-alert{background:rgba(224,82,82,.2);color:#ff6b6b;border-color:rgba(224,82,82,.6)}
.sb-toast{position:absolute;left:50%;top:20%;transform:translateX(-50%);font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:22px;font-weight:700;color:#e8dcc0;text-shadow:0 0 18px currentColor;opacity:0;transition:opacity .18s ease;pointer-events:none;text-align:center}
.sb-toast .sb-sub{display:block;font-size:14px;font-weight:400;color:#b9d6d0;margin-top:6px;text-shadow:none}
.sb-toast.sb-on{opacity:1}
`;

function ensureStyle(root: HTMLElement): void {
  if (root.querySelector('#sb-style')) return;
  const style = document.createElement('style');
  style.id = 'sb-style';
  style.textContent = css;
  root.appendChild(style);
}

export interface SkillBarHandle {
  items: GameItem[];
  /** 使用提示大字元素，交给场景系统投影到怪物头顶 */
  toastElement?: HTMLElement;
  dispose: () => void;
}

/** 道具被使用时回调，供场景系统投放物体 / 给目标挂 debuff */
export type OnItemUse = (item: GameItem) => void;

/**
 * Installs a 3-slot item/skill bar into the engine-provided #game-ui DOM layer.
 * Visuals follow the planning doc: isometric palette (dark teal / warm safe-room
 * yellow / alert red), rule-horror notice board, and a "fake safe room" twist.
 */
export function installSkillBar(world: World, onUse?: OnItemUse): SkillBarHandle {
  const root = document.querySelector('#game-ui');
  if (!(root instanceof HTMLElement)) {
    return { items: ITEMS, dispose: () => {} };
  }
  ensureStyle(root);

  const hud = document.createElement('div');
  hud.className = 'sb-hud';
  const slots: HTMLElement[] = [];
  const counts: HTMLElement[] = [];

  for (const item of ITEMS) {
    const slot = document.createElement('div');
    slot.className = 'sb-slot';

    const key = document.createElement('div');
    key.className = 'sb-key';
    key.textContent = item.keyLabel;

    const glyph = document.createElement('div');
    glyph.className = 'sb-glyph';
    glyph.style.color = item.color;
    glyph.textContent = item.glyph;

    const count = document.createElement('div');
    count.className = 'sb-count';
    count.textContent = String(item.count);

    const name = document.createElement('div');
    name.className = 'sb-name';
    name.textContent = item.name;

    slot.append(key, glyph, count, name);
    hud.appendChild(slot);
    slots.push(slot);
    counts.push(count);
  }

  // 告示面板：标题 + 警戒标记 + 规则怪谈文案 + 播报行
  const log = document.createElement('div');
  log.className = 'sb-log';
  const titleRow = document.createElement('div');
  titleRow.className = 'sb-log-title';
  titleRow.textContent = FLAVOR.noticeTitle;
  const alertBadge = document.createElement('span');
  alertBadge.className = 'sb-alert';
  alertBadge.textContent = FLAVOR.safe;
  titleRow.appendChild(alertBadge);
  const rule = document.createElement('div');
  rule.className = 'sb-rule';
  rule.textContent = FLAVOR.noticeRule;
  const linesBox = document.createElement('div');
  linesBox.className = 'sb-lines';
  log.append(titleRow, rule, linesBox);

  const toast = document.createElement('div');
  toast.className = 'sb-toast';

  root.append(hud, log, toast);

  const lines: string[] = [];
  let alert = 0; // 警戒度：用道具累积，跨过阈值触发伪安全彩蛋
  let betrayed = false;

  function setAlert(next: number): void {
    alert = next;
    const danger = alert >= 3;
    log.classList.toggle('sb-danger', danger);
    alertBadge.textContent = danger ? FLAVOR.alert : FLAVOR.safe;
    rule.textContent = danger ? FLAVOR.fakeSafe : FLAVOR.noticeRule;
    if (danger && !betrayed) {
      betrayed = true;
      broadcast('告示渗出了原本没有的字迹。');
    }
  }

  function broadcast(text: string): void {
    lines.unshift(text);
    if (lines.length > 6) lines.pop();
    linesBox.innerHTML = '';
    for (const line of lines) {
      const el = document.createElement('div');
      el.className = 'sb-line';
      el.textContent = line;
      linesBox.appendChild(el);
    }
  }

  function refreshSlot(index: number): void {
    const item = ITEMS[index];
    if (!item) return;
    counts[index]!.textContent = String(item.count);
    slots[index]!.classList.toggle('sb-empty', item.count <= 0);
  }

  function flashSlot(index: number, betray = false): void {
    const slot = slots[index];
    if (!slot) return;
    slot.classList.add(betray ? 'sb-betray' : 'sb-used');
    window.setTimeout(() => slot.classList.remove('sb-used', 'sb-betray'), 420);
  }

  function showToast(item: GameItem, sub?: string): void {
    toast.innerHTML = '';
    toast.textContent = `${item.name} · ${item.effect}`;
    toast.style.color = item.color;
    const s = document.createElement('span');
    s.className = 'sb-sub';
    s.textContent = sub ?? item.notice;
    toast.appendChild(s);
    toast.classList.add('sb-on');
    window.setTimeout(() => toast.classList.remove('sb-on'), 1100);
  }

  broadcast('系统就绪 · 按 1 / 2 / 3 使用道具');
  broadcast(FLAVOR.noticeHint);

  world
    .addSystem(Update, {
      name: 'skillbar-input',
      queries: [],
      fn: () => {
        const input = world.getResource<InputSnapshot>(INPUT_SNAPSHOT_RESOURCE_KEY);
        ITEMS.forEach((item, index) => {
          if (!input.keyboard.justPressedCode(item.keyCode)) return;

          if (item.count <= 0) {
            broadcast(`${item.name} 已用尽 · ${item.notice}`);
            return;
          }

          // 伪安全彩蛋：警戒后使用第 3 件物品，"声响"反而引来更多注意。
          // 必须放在 placed-unused 分支之前，否则诱饵首次布置会拦截它。
          if (item.slot === 3 && alert >= 3) {
            item.count -= 1;
            item.status = 'used';
            setAlert(alert + 1);
            flashSlot(index, true);
            refreshSlot(index);
            broadcast(`诱饵反向生效 · 声响引来更多注意 · ${item.notice} · 剩余 ${item.count}`);
            showToast(item, FLAVOR.fakeSafe);
            onUse?.(item);
            return;
          }

          // 布置类道具第二次按下：触发
          if (item.status === 'placed-unused') {
            item.status = 'placed-used';
            setAlert(alert + 1);
            flashSlot(index);
            refreshSlot(index);
            broadcast(`${item.name} 已触发 · ${item.notice} · ${STATUS_LABEL[item.status]}`);
            showToast(item);
            onUse?.(item);
            return;
          }

          item.count -= 1;
          item.status = item.slot === 1 ? 'flying' : 'placed-unused';
          slots[index]!.classList.add('sb-selected');
          setAlert(alert + 1);
          flashSlot(index);
          refreshSlot(index);
          broadcast(`使用 ${item.name} → ${item.effect} · 剩余 ${item.count} · ${STATUS_LABEL[item.status]}`);
          showToast(item);
          onUse?.(item);

          // 投射物飞行后命中：怪谈式命中播报
          if (item.status === 'flying') {
            const captured = item;
            window.setTimeout(() => {
              captured.status = 'hit';
              slots[index]!.classList.remove('sb-selected');
              broadcast(`${captured.name} 已碰撞 · 目标陷入停滞 · 范围 ${captured.range}m`);
            }, 550);
          }
        });
      },
    })
    .unwrap();

  return {
    items: ITEMS,
    toastElement: toast,
    dispose: () => {
      world.removeSystem(Update, 'skillbar-input').unwrap();
      hud.remove();
      log.remove();
      toast.remove();
      root.querySelector('#sb-style')?.remove();
    },
  };
}
