import { Update, type EntityHandle, type World } from '@forgeax/engine/ecs';
import type { Handle } from '@forgeax/engine/types';
import { Name, Transform } from '@forgeax/engine/scene';
import { Camera, MeshFilter, MeshRenderer, Materials } from '@forgeax/engine/render';
import { HANDLE_CUBE, HANDLE_SPHERE, decodeImageBytes } from '@forgeax/engine/assets-runtime';
import { mat4, quat, ray, vec2, vec3 } from '@forgeax/engine/math';
import type { GameHost } from '@forgeax/engine/app';
import { DEBUFFS, type DebuffId } from './debuffs/index.ts';

/**
 * 运行时场景角色系统：
 * - 投放带贴图的诱饵物体（按 3 时在玩家面前生成）
 * - 一个"怪物"目标（带贴图），被施加 debuff 时头顶显示文字
 * 贴图用 canvas 程序化生成，不依赖外部图片资源。
 */

type TexHandle = ReturnType<World['allocSharedRef']>;

interface ActiveDebuff {
  id: DebuffId;
  until: number;
  el: HTMLElement;
}

export interface SceneActorsHandle {
  /** 在指定世界坐标投放一个诱饵物体 */
  deployDecoy: (pos: readonly [number, number, number]) => void;
  /** 给怪物施加一个负面效果（头顶文字） */
  applyDebuff: (id: DebuffId) => void;
  /** 把使用提示大字挂到怪物头顶（传 skillbar 的 toast 元素） */
  setToast: (el: HTMLElement | undefined) => void;
  playerPos: () => readonly [number, number, number];
  dispose: () => void;
}

function canvasTextureDataUrl(draw: (ctx: CanvasRenderingContext2D, s: number) => void, size = 128): string {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('2d context unavailable');
  draw(ctx, size);
  return canvas.toDataURL('image/png');
}

async function dataUrlToTex(
  world: World,
  host: GameHost,
  dataUrl: string,
): Promise<TexHandle | undefined> {
  try {
    const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const res = await decodeImageBytes(bytes, 'image/png');
    if (!res.ok) {
      console.warn('[scene-actors] decodeImageBytes failed:', res.error);
      return undefined;
    }
    // 有些构建把 assets 挂在 host.renderer 上；两种都尝试
    void host.assets;
    return world.allocSharedRef('TextureAsset', res.value);
  } catch (e) {
    console.warn('[scene-actors] texture build failed:', e);
    return undefined;
  }
}

function materialWithTex(world: World, tex: TexHandle | undefined, rgba: readonly [number, number, number, number], emissive?: readonly [number, number, number]): Handle<'MaterialAsset', 'shared'> {
  const payload = Materials.standard({
    baseColor: rgba,
    roughness: 0.6,
    metallic: 0.05,
    emissive,
    emissiveIntensity: emissive ? 0.6 : undefined,
    ...(tex !== undefined ? { baseColorTexture: { texture: tex } } : {}),
  });
  return world.allocSharedRef('MaterialAsset', payload);
}

export function installSceneActors(world: World, host: GameHost, player: EntityHandle, camera: EntityHandle): SceneActorsHandle {
  const root = (host.uiRoot ?? document.body) as HTMLElement;

  // ---- 贴图绘制 ----
  const decoyUrl = canvasTextureDataUrl((ctx, s) => {
    ctx.fillStyle = '#2b1414';
    ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = '#e05252';
    ctx.lineWidth = 6;
    ctx.strokeRect(8, 8, s - 16, s - 16);
    ctx.fillStyle = '#ffd9d9';
    ctx.font = `bold ${Math.round(s * 0.5)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('饵', s / 2, s / 2 + 4);
  });
  const monsterUrl = canvasTextureDataUrl((ctx, s) => {
    ctx.fillStyle = '#1a1a24';
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#b83c3c';
    ctx.beginPath(); ctx.arc(s * 0.36, s * 0.42, s * 0.1, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(s * 0.64, s * 0.42, s * 0.1, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#e05252'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.arc(s / 2, s * 0.58, s * 0.22, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke();
    ctx.fillStyle = '#5fd4c4';
    ctx.font = `${Math.round(s * 0.16)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText('????', s / 2, s * 0.9);
  });

  const decoys: EntityHandle[] = [];
  let monster: EntityHandle | undefined;
  let monsterMat: Handle<'MaterialAsset', 'shared'> | undefined;
  let decoyMat: Handle<'MaterialAsset', 'shared'> | undefined;
  let toastEl: HTMLElement | undefined;

  // 先建纯色材质，贴图异步解码后再替换
  const monsterMatPlain = materialWithTex(world, undefined, [0.72, 0.22, 0.22, 1], [0.25, 0.03, 0.03]);
  const decoyMatPlain = materialWithTex(world, undefined, [0.88, 0.32, 0.32, 1], [0.3, 0.06, 0.06]);

  // 怪物目标：放在玩家前方偏侧的位置（等距相机下靠近画面中心，避免被裁切）
  const p0 = world.get(player, Transform).unwrap().pos;
  const monsterPos = [(p0[0] ?? 0) + 2.5, 0.9, (p0[2] ?? 0) - 2.5] as const;
  monster = world.spawn(
    { component: Transform, data: { pos: monsterPos, scale: [1.1, 1.3, 1.1] } },
    { component: Name, data: { value: 'DebuffTarget' } },
    { component: MeshFilter, data: { assetHandle: HANDLE_SPHERE } },
    { component: MeshRenderer, data: { materials: [monsterMatPlain] } },
  ).unwrap();

  // 异步替换贴图材质
  void (async () => {
    const [dTex, mTex] = await Promise.all([
      dataUrlToTex(world, host, decoyUrl),
      dataUrlToTex(world, host, monsterUrl),
    ]);
    if (dTex !== undefined) decoyMat = materialWithTex(world, dTex, [1, 1, 1, 1]);
    if (mTex !== undefined) monsterMat = materialWithTex(world, mTex, [1, 1, 1, 1], [0.15, 0.05, 0.05]);
    if (monster !== undefined && monsterMat !== undefined) {
      world.set(monster, MeshRenderer, { materials: [monsterMat] }).unwrap();
    }
  })();

  // ---- 头顶 debuff 文字层（DOM 覆盖）----
  const labelLayer = document.createElement('div');
  labelLayer.className = 'sb-debuff-layer';
  labelLayer.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:5';
  root.appendChild(labelLayer);
  if (!root.querySelector('#sb-debuff-style')) {
    const st = document.createElement('style');
    st.id = 'sb-debuff-style';
    st.textContent = `
    .sb-debuff-tag{position:absolute;transform:translate(-50%,-100%);display:flex;align-items:center;gap:4px;
      padding:3px 8px;border-radius:6px;font-family:system-ui,sans-serif;font-size:13px;font-weight:700;
      color:#fff;white-space:nowrap;background:rgba(20,10,10,.86);border:1px solid currentColor;
      box-shadow:0 2px 12px rgba(0,0,0,.6);transition:opacity .2s}
    .sb-debuff-tag .sb-folder{font-size:13px}
    `;
    root.appendChild(st);
  }

  const active: ActiveDebuff[] = [];

  function applyDebuff(id: DebuffId): void {
    if (monster === undefined) return;
    const def = DEBUFFS[id];
    const now = performance.now() / 1000;
    const el = document.createElement('div');
    el.className = 'sb-debuff-tag';
    el.style.color = def.color;
    el.innerHTML = `<span class="sb-folder">${def.icon}</span><span>${def.label}</span>`;
    labelLayer.appendChild(el);
    active.push({ id, until: now + def.duration, el });
  }

  function deployDecoy(pos: readonly [number, number, number]): void {
    const mat = decoyMat ?? decoyMatPlain;
    const e = world.spawn(
      { component: Transform, data: { pos: [pos[0], 0.35, pos[2]], scale: [0.7, 0.7, 0.7] } },
      { component: Name, data: { value: 'Decoy' } },
      { component: MeshFilter, data: { assetHandle: HANDLE_CUBE } },
      { component: MeshRenderer, data: { materials: [mat] } },
    ).unwrap();
    decoys.push(e);
    while (decoys.length > 3) {
      const old = decoys.shift();
      if (old !== undefined) world.despawn(old).unwrap();
    }
  }

  const px = vec2.create();
  const eye = vec3.create();
  const fwd = vec3.create();
  const target = vec3.create();
  const vp = mat4.create();
  const head = vec3.create();

  function projectHead(targetHandle: EntityHandle, worldY: number): boolean {
    // 用 Transform.pos/quat 的当前值（跟随系统每帧写入），不要用 .world（渲染缓存矩阵，可能滞后）
    const camT = world.get(camera, Transform).unwrap();
    const cp = camT.pos;
    eye[0] = cp[0] ?? 0; eye[1] = cp[1] ?? 0; eye[2] = cp[2] ?? 0;
    const cq = camT.quat;
    quat.transformVec3(fwd, [cq[0] ?? 0, cq[1] ?? 0, cq[2] ?? 0, cq[3] ?? 1], [0, 0, -1]);
    vec3.add(target, eye, fwd);
    const cam = world.get(camera, Camera).unwrap();
    const aspect = host.canvas.width / Math.max(1, host.canvas.height);
    mat4.computeViewProj(vp, eye, target, [0, 1, 0], cam.fov, aspect, cam.near, cam.far);

    const mp = world.get(targetHandle, Transform).unwrap().pos;
    head[0] = mp[0] ?? 0; head[1] = worldY; head[2] = mp[2] ?? 0;
    const r = ray.worldToScreen(px, head, vp, host.canvas.width, host.canvas.height);
    return r.onScreen && !r.behind;
  }

  function updateHeadLabels(): void {
    const m = monster;
    if (m === undefined) return;
    const now = performance.now() / 1000;
    // 清理过期
    for (let i = active.length - 1; i >= 0; i--) {
      if (active[i]!.until <= now) {
        active[i]!.el.remove();
        active.splice(i, 1);
      }
    }
    if (active.length === 0 && toastEl === undefined) return;

    const baseY = world.get(m, Transform).unwrap().pos[1] ?? 0;

    // 使用提示大字：贴在怪物头顶最高处
    if (toastEl !== undefined) {
      if (projectHead(m, baseY + 2.5 + active.length * 0.42)) {
        toastEl.style.display = 'block';
        toastEl.style.left = `${px[0]}px`;
        toastEl.style.top = `${px[1]}px`;
      } else {
        toastEl.style.display = 'none';
      }
    }

    // debuff 标签：从怪物头顶往上逐个排列
    active.forEach((a, i) => {
      if (projectHead(m, baseY + 1.6 + i * 0.42)) {
        a.el.style.display = 'flex';
        a.el.style.left = `${px[0]}px`;
        a.el.style.top = `${px[1]}px`;
      } else {
        a.el.style.display = 'none';
      }
    });
  }

  world.addSystem(Update, {
    name: 'scene-actors-labels',
    after: ['game-3d-camera-follow'],
    queries: [],
    fn: updateHeadLabels,
  }).unwrap();

  return {
    deployDecoy,
    applyDebuff,
    setToast: (el: HTMLElement | undefined) => {
      toastEl = el;
      if (el !== undefined) {
        // 底部对齐怪物头顶锚点，水平居中
        el.style.transform = 'translate(-50%, -100%)';
      }
    },
    playerPos: () => {
      const t = world.get(player, Transform).unwrap().pos;
      return [t[0] ?? 0, t[1] ?? 0, t[2] ?? 0];
    },
    dispose: () => {
      world.removeSystem(Update, 'scene-actors-labels').unwrap();
      for (const a of active) a.el.remove();
      labelLayer.remove();
      for (const d of decoys) world.despawn(d).unwrap();
      if (monster !== undefined) world.despawn(monster).unwrap();
    },
  };
}
