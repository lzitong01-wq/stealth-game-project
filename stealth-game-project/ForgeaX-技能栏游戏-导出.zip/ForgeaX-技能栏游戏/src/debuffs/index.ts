/**
 * 目标负面效果（debuff）配置。
 * 把"怪物头顶显示的负面状态"集中放到这个文件夹里管理，
 * 与技能栏道具通过 id 关联。
 */

export interface DebuffDef {
  id: string;
  /** 头顶显示的文字 */
  label: string;
  /** 文件夹式标签图标 */
  icon: string;
  /** 持续时间（秒） */
  duration: number;
  /** 显示色（十六进制） */
  color: string;
}

export const DEBUFFS = {
  stun: { id: 'stun', label: '眩晕 · 停滞 2s', icon: '📁', duration: 2, color: '#e8c987' },
  paralysis: { id: 'paralysis', label: '麻痹 · 3s', icon: '📁', duration: 3, color: '#5fd4c4' },
  lure: { id: 'lure', label: '被诱导', icon: '📁', duration: 4, color: '#e05252' },
} as const satisfies Record<string, DebuffDef>;

export type DebuffId = keyof typeof DEBUFFS;

/** 道具槽位 → 施加给目标的 debuff */
export const SLOT_DEBUFF: Record<number, DebuffId> = {
  1: 'stun',
  2: 'paralysis',
  3: 'lure',
};
