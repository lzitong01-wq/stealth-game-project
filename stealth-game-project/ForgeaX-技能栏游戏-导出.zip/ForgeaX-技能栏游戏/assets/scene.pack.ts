import { quat } from '@forgeax/engine/math';
import type { ScriptablePackDefinition } from '@forgeax/engine/pack/source';
import {
  CharacterController,
  Collider,
  ColliderShapeValue,
  RigidBody,
  RigidBodyTypeValue,
} from '@forgeax/engine/physics';
import {
  ANTIALIAS_FXAA,
  Camera,
  DirectionalLight,
  MeshFilter,
  MeshRenderer,
  perspective,
  PointLight,
  SKYBOX_MODE_CUBEMAP,
  SkyboxBackground,
  Skylight,
  TONEMAP_ACES_FILMIC,
} from '@forgeax/engine/render';
import { ChildOf, Name, Transform } from '@forgeax/engine/scene';
import type { AssetGuid, LocalEntityId, SceneAsset, SceneEntity } from '@forgeax/engine/types';
import { ok } from '@forgeax/engine/types';
import {
  ASSET_IDS,
  guidText,
  PACKAGE_IDS,
  SUN_OUTGOING_DIRECTION,
} from '../src/asset-ids.ts';

const assets = {
  'scene/showcase': {
    guid: ASSET_IDS.showcaseScene,
    kind: 'scene',
    name: 'Game 3D / Lighting Showcase',
  },
} as const;

function meshEntity(
  localId: number,
  name: string,
  mesh: AssetGuid,
  position: readonly [number, number, number],
  scale: readonly [number, number, number] = [1, 1, 1],
  rotation: readonly [number, number, number, number] = [0, 0, 0, 1],
  extra: Record<string, Record<string, unknown>> = {},
): SceneEntity {
  return {
    localId: localId as LocalEntityId,
    components: {
      Name: { value: name },
      Transform: { pos: position, scale, quat: rotation },
      MeshFilter: { assetHandle: guidText(mesh) },
      MeshRenderer: { materials: [] },
      ...extra,
    },
  };
}

function showcaseScene(): SceneAsset {
  // 相机初始就放在等距位置（玩家初始 0,0.93,9 + 偏移 10,11,10），避免启动时从旧位置插值收敛
  const cameraPosition = [10, 11.93, 19] as const;
  const target = [0, 1.38, 9] as const;
  const cameraRotation = quat.fromLookAt(quat.create(), cameraPosition, target, [0, 1, 0]);
  return {
    kind: 'scene',
    entities: [
      meshEntity(0, 'Ground', ASSET_IDS.groundMesh, [0, -0.2, 0], [1, 1, 1], [0, 0, 0, 1], {
        RigidBody: { type: RigidBodyTypeValue.static },
        Collider: {
          shape: ColliderShapeValue.cuboid,
          halfExtents: [24, 0.2, 24],
          friction: 0.9,
          restitution: 0,
        },
      }),
      {
        localId: 6 as LocalEntityId,
        components: {
          Name: { value: 'Sun' },
          DirectionalLight: {
            direction: SUN_OUTGOING_DIRECTION,
            color: [1, 0.98, 0.93],
            intensity: 3.2,
            castShadow: true,
            cascadeCount: 3,
            splitLambda: 0.72,
            cascadeBlend: 0.18,
            mapSize: 2048,
            depthBias: 0.005,
            normalBias: 0.06,
            shadowDistance: 72,
            pcfKernelSize: 3,
          },
        },
      },
      {
        localId: 7 as LocalEntityId,
        components: {
          Name: { value: 'Warm Point Light' },
          Transform: { pos: [0, 4.2, 0] },
          PointLight: { color: [1, 0.32, 0.08], intensity: 45, range: 11 },
        },
      },
      {
        localId: 8 as LocalEntityId,
        components: {
          Name: { value: 'Analytic Skylight' },
          Skylight: {
            equirect: guidText(ASSET_IDS.daylight),
            color: [1, 1, 1],
            intensity: 0.8,
          },
        },
      },
      {
        localId: 9 as LocalEntityId,
        components: {
          Name: { value: 'Analytic Sky Background' },
          SkyboxBackground: {
            equirect: guidText(ASSET_IDS.daylight),
            mode: SKYBOX_MODE_CUBEMAP,
          },
        },
      },
      {
        localId: 10 as LocalEntityId,
        components: {
          Name: { value: 'Main Camera' },
          Transform: {
            pos: cameraPosition,
            quat: [
              cameraRotation[0] ?? 0,
              cameraRotation[1] ?? 0,
              cameraRotation[2] ?? 0,
              cameraRotation[3] ?? 1,
            ],
          },
          Camera: {
            ...perspective({ fov: Math.PI / 4, aspect: 16 / 9, near: 0.1, far: 160 }),
            tonemap: TONEMAP_ACES_FILMIC,
            exposure: 0.9,
            antialias: ANTIALIAS_FXAA,
            clearColor: [0.18, 0.36, 0.68, 1],
          },
        },
      },
      meshEntity(11, 'Player', ASSET_IDS.playerMesh, [0, 0.93, 9], [1, 1, 1], [0, 0, 0, 1], {
        RigidBody: { type: RigidBodyTypeValue.kinematic },
        Collider: {
          shape: ColliderShapeValue.capsule,
          radius: 0.38,
          halfHeight: 0.55,
          friction: 0.7,
          restitution: 0,
        },
        CharacterController: {
          offset: 0.03,
          maxSlopeClimbDeg: 48,
          minSlopeSlideDeg: 55,
          autoStepMaxHeight: 0.32,
          autoStepMinWidth: 0.15,
          snapToGroundDist: 0.24,
        },
      }),
      meshEntity(12, 'Player Heading Marker', ASSET_IDS.playerMarkerMesh, [0, 0.34, -0.39], [1, 1, 1], [0, 0, 0, 1], {
        ChildOf: { parent: 11 },
      }),
    ],
  };
}

export default {
  schemaVersion: '1.0.0',
  packageId: PACKAGE_IDS.scene,
  name: 'Game 3D / Scene',
  assets,
  sceneComponents: [
    Camera,
    CharacterController,
    ChildOf,
    Collider,
    DirectionalLight,
    MeshFilter,
    MeshRenderer,
    Name,
    PointLight,
    RigidBody,
    SkyboxBackground,
    Skylight,
    Transform,
  ],
  externalAssets: {
    daylight: ASSET_IDS.daylight,
    groundMesh: ASSET_IDS.groundMesh,
    playerMesh: ASSET_IDS.playerMesh,
    playerMarkerMesh: ASSET_IDS.playerMarkerMesh,
  },
  build: () => ok({ 'scene/showcase': showcaseScene() }),
} satisfies ScriptablePackDefinition<typeof assets>;
